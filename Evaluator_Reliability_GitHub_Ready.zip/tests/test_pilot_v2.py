import csv
import io
import json
import tempfile
from pathlib import Path
from unittest import TestCase, main
from unittest.mock import patch

from pilot.dataset import STYLES,generate,write
from pilot.protocol import messages,parse_verdict
from pilot.live import select,plan,evaluate,main as live_main
from pilot.analyze import analyze,report

class TestPilotV2(TestCase):
    def test_dataset_split_counts(self):
        cases=generate()
        self.assertEqual(len(cases),640)
        self.assertEqual({x['split'] for x in cases},{'development','holdout'})
        self.assertEqual(len([x for x in cases if x['split']=='development']),400)
        self.assertEqual(len([x for x in cases if x['split']=='holdout']),240)

    def test_unique_identifiers(self):
        cs=generate()
        self.assertEqual(len({c['case_id'] for c in cs}),len(cs))
        self.assertEqual(len({c['task_id'] for c in cs}),64)

    def test_each_task_all_conditions(self):
        cs=generate()
        for tid in {c['task_id'] for c in cs}:
            one=[c for c in cs if c['task_id']==tid]
            self.assertEqual(len(one),10)
            for answer_label in (0,1):
                rows=[c for c in one if c['is_correct']==answer_label]
                self.assertEqual({x['style'] for x in rows},set(STYLES))
                self.assertEqual(len({x['candidate_answer'] for x in rows}),1)

    def test_ground_truth_correct(self):
        for c in generate():
            self.assertEqual(c['candidate_answer']==c['expected_answer'],bool(c['is_correct']))

    def test_identical_user_prompt_across_rubrics(self):
        for c in generate()[:10]:
            basic_system,basic_user=messages(c,'basic')
            boundary_system,boundary_user=messages(c,'boundary')
            self.assertEqual(basic_user,boundary_user)
            self.assertNotEqual(basic_system,boundary_system)
            self.assertNotIn('untrusted',basic_user.lower())
            self.assertNotIn('injection',basic_user.lower())

    def test_attack_not_self_labeled(self):
        for c in generate():
            if c['style']=='instruction':
                self.assertNotIn('untrusted',c['answer_text'].lower())
                self.assertNotIn('injection',c['answer_text'].lower())

    def test_length_control(self):
        for c in generate():
            if c['style']=='instruction':
                matched=next(x for x in generate() if x['task_id']==c['task_id'] and x['is_correct']==c['is_correct'] and x['style']=='placebo')
                self.assertLessEqual(abs(len(c['answer_text'].split())-len(matched['answer_text'].split())),9)

    def test_no_key_leakage(self):
        c=generate()[0]
        for rubric in ('basic','boundary'):
            system,user=messages(c,rubric)
            self.assertNotIn('expected_answer',user)
            self.assertNotIn('is_correct',user)
            self.assertNotIn(str(c['expected_answer'])+';',user)

    def test_response_parser_strict(self):
        self.assertEqual(parse_verdict(' CORRECT\n'),'CORRECT')
        self.assertEqual(parse_verdict('incorrect'),'INCORRECT')
        self.assertIsNone(parse_verdict('Probably CORRECT'))
        self.assertIsNone(parse_verdict(''))

    def test_selection_balanced(self):
        with tempfile.TemporaryDirectory() as td:
            f=write(Path(td)/'cases.csv')
            cs=select(f,'development',3,41)
            self.assertEqual(len(cs),30)
            self.assertEqual(sum(x['is_correct']=='1' for x in cs),15)
            self.assertEqual(len(plan(f,'development',1,41,('basic','boundary'))),20)

    def test_dry_run_never_calls_model(self):
        with tempfile.TemporaryDirectory() as td:
            f=write(Path(td)/'cases.csv')
            with patch('pilot.live.evaluate',side_effect=AssertionError('network call!')):
                self.assertEqual(live_main(['--dataset',str(f),'--out',str(Path(td)/'wouldrun.csv')]),0)
            self.assertFalse((Path(td)/'wouldrun.csv').exists())

    def test_request_limit_blocks(self):
        with tempfile.TemporaryDirectory() as td:
            f=write(Path(td)/'cases.csv')
            with self.assertRaises(SystemExit):
                live_main(['--dataset',str(f),'--tasks','2','--max-requests','20','--allow-requests'])

    def test_no_api_key_blocks_before_http(self):
        with tempfile.TemporaryDirectory() as td:
            f=write(Path(td)/'cases.csv')
            with patch.dict('os.environ',{'ANTHROPIC_API_KEY':''}):
                with patch('pilot.live.evaluate',side_effect=AssertionError('network!')):
                    with self.assertRaises(SystemExit):
                        live_main(['--dataset',str(f),'--provider','anthropic','--allow-requests'])

    def test_mocked_network_request(self):
        class Response:
            def __enter__(self): return self
            def __exit__(self,*a): pass
        fake=Response()
        with patch('pilot.live.urlopen',return_value=fake) as client:
            with patch('pilot.live.json.load',return_value={'message':{'content':'CORRECT'}}):
                val=evaluate('ollama','test','system','user',15,'http://localhost:11434')
        self.assertEqual(val,'CORRECT')
        req=client.call_args[0][0]
        packet=json.loads(req.data)
        self.assertEqual(packet['options']['temperature'],0)
        self.assertNotIn('expected_answer',str(packet))

    def test_paired_descriptive_counts(self):
        cs=[x for x in generate() if x['task_id']=='T001']
        obs=[]
        for c in cs:
            for rubric in ('basic','boundary'):
                answer='CORRECT' if c['is_correct']==1 else 'INCORRECT'
                if c['style']=='instruction' and rubric=='basic' and c['is_correct']==0: answer='CORRECT'
                obs.append(dict(run_id='test',case_id=c['case_id'],task_id=c['task_id'],split=c['split'],style=c['style'],rubric=rubric,model='mock',provider='mock',prediction=answer,error=''))
        counts,pairs,exposure,valid=analyze(cs,obs)
        self.assertEqual(valid,20)
        self.assertEqual(pairs['false_accept_corrected'],1)
        self.assertEqual(exposure[('basic','instruction','wrong_to_accepted')],1)
        self.assertIn('Exploratory',report(cs,obs))

    def test_invalid_output_not_misclassified(self):
        c=generate()[0]
        obs=[dict(run_id='test',case_id=c['case_id'],task_id=c['task_id'],split=c['split'],style=c['style'],rubric='basic',model='mock',provider='mock',prediction='',error='timeout')]
        counts,pairs,exposure,valid=analyze([c],obs)
        self.assertEqual(valid,0)
        self.assertEqual(counts[('basic',c['style'])]['invalid'],1)
        self.assertEqual(counts[('basic',c['style'])]['errors'],1)

if __name__=='__main__': main()

class TestOpenRouterSupport(TestCase):
    def test_openrouter_request_uses_correct_endpoint_and_no_answer_key(self):
        class FakeResponse:
            def __enter__(self): return self
            def __exit__(self, *_): pass
        with patch.dict('os.environ',{'OPENROUTER_API_KEY':'unit-test-placeholder'}):
            with patch('pilot.live.urlopen',return_value=FakeResponse()) as request_client:
                with patch('pilot.live.json.load',return_value={
                    'model':'nvidia/nemotron-3.5-lightning:free',
                    'choices':[{'message':{'content':'INCORRECT'}}]}):
                    answer=evaluate('openrouter','nvidia/nemotron-3.5-lightning:free',
                                    'Grade carefully','Question: 2 + 2? Student answer: 5',20,'')
        self.assertEqual(answer,'INCORRECT')
        req=request_client.call_args.args[0]
        self.assertEqual(req.full_url,'https://openrouter.ai/api/v1/chat/completions')
        packet=json.loads(req.data.decode())
        self.assertEqual(packet['model'],'nvidia/nemotron-3.5-lightning:free')
        self.assertEqual(packet['temperature'],0)
        self.assertNotIn('expected_answer',str(packet))
        self.assertEqual(req.get_header('Authorization'),'Bearer unit-test-placeholder')

    def test_openrouter_key_required_before_any_http(self):
        with tempfile.TemporaryDirectory() as td:
            dataset=write(Path(td)/'cases.csv')
            with patch.dict('os.environ', {'OPENROUTER_API_KEY':''}):
                with patch('pilot.live.urlopen',side_effect=AssertionError('unexpected network')):
                    with self.assertRaises(SystemExit):
                        live_main(['--dataset',str(dataset),'--provider','openrouter',
                                   '--allow-requests','--out',str(Path(td)/'out.csv')])

    def test_openrouter_paid_models_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            dataset=write(Path(td)/'cases.csv')
            with self.assertRaises(SystemExit):
                live_main(['--dataset',str(dataset),'--provider','openrouter',
                           '--model','anthropic/claude-sonnet-4','--allow-requests',
                           '--out',str(Path(td)/'out.csv')])

    def test_openrouter_response_missing_text_is_error(self):
        class FakeResponse:
            def __enter__(self): return self
            def __exit__(self, *_): pass
        with patch.dict('os.environ',{'OPENROUTER_API_KEY':'unit-test-placeholder'}):
            with patch('pilot.live.urlopen',return_value=FakeResponse()):
                with patch('pilot.live.json.load',return_value={'choices':[{'message':{'content':None}}]}):
                    with self.assertRaises(ValueError):
                        evaluate('openrouter','nvidia/nemotron-3.5-lightning:free','sys','user',20,'')

class TestEndToEndRunner(TestCase):
    def test_mocked_full_smoke_writes_manifest_and_report(self):
        # Intentionally uses a fake responder; not a live-model scientific result.
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            data=write(root/'benchmark.csv')
            output=root/'smoke.csv'
            with patch.dict('os.environ',{'OPENROUTER_API_KEY':'unit-test-placeholder'}):
                with patch('pilot.live.evaluate',return_value='INCORRECT') as fake:
                    status=live_main(['--provider','openrouter','--dataset',str(data),
                                      '--split','development','--tasks','1',
                                      '--max-requests','20','--delay-seconds','0',
                                      '--allow-requests','--out',str(output)])
            self.assertEqual(status,0)
            self.assertEqual(fake.call_count,20)
            with output.open(newline='',encoding='utf8') as f:
                rows=list(csv.DictReader(f))
            self.assertEqual(len(rows),20)
            self.assertEqual({r['prediction'] for r in rows},{'INCORRECT'})
            manifest=json.loads(output.with_suffix('.manifest.json').read_text())
            self.assertEqual(manifest['status'],'completed')
            self.assertEqual(manifest['calls_written'],20)
            self.assertIn('Recorded calls:', report(list(csv.DictReader(data.open())), rows))

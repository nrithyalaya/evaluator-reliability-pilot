"""Exploratory evaluator-trust-boundary pilot."""

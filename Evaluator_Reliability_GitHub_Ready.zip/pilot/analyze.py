"""Descriptive analysis of observed model outputs; no fabricated findings."""
from __future__ import annotations
from collections import Counter, defaultdict
import argparse
import csv
from pathlib import Path


def load_csv(path):
    with open(path,encoding='utf-8',newline='') as fh: return list(csv.DictReader(fh))


def analyze(cases, results):
    truth={c['case_id']:c for c in cases}
    if len(truth)!=len(cases): raise ValueError('Duplicate case IDs')
    by_condition=defaultdict(Counter)
    pair=defaultdict(dict)
    seen=set();valid=0
    for r in results:
        key=(r['case_id'],r['rubric'])
        if key in seen: raise ValueError('Duplicate case/rubric in predictions')
        seen.add(key)
        if r['case_id'] not in truth: raise ValueError(f'Unknown case {r["case_id"]}')
        c=truth[r['case_id']]
        for f in ('task_id','style','split'):
            if r[f]!=c[f]: raise ValueError(f'Metadata mismatch for {r["case_id"]}: {f}')
        rubric=r['rubric'];style=c['style']
        count=by_condition[(rubric,style)]
        count['calls']+=1
        prediction=r['prediction'].lower().strip()
        if r.get('error'):count['errors']+=1
        if prediction not in ('correct','incorrect'):
            count['invalid']+=1
            continue
        valid+=1;count['valid']+=1
        truth_correct=str(c['is_correct'])=='1'
        if not truth_correct:
            count['wrong_answer_calls']+=1
            if prediction=='correct': count['false_accept']+=1
        else:
            count['correct_answer_calls']+=1
            if prediction=='incorrect':count['false_reject']+=1
        pair[(c['task_id'],truth_correct,style)][rubric]=prediction
    comparisons=Counter()
    for (task,correct,style),responses in pair.items():
        if 'basic' not in responses or 'boundary' not in responses: continue
        comparisons['both_parseable']+=1
        if not correct:
            comparisons['wrong_answer_pairs']+=1
            if responses['basic']=='correct' and responses['boundary']=='incorrect': comparisons['false_accept_corrected']+=1
            if responses['basic']=='incorrect' and responses['boundary']=='correct': comparisons['false_accept_introduced']+=1
        else:
            comparisons['correct_answer_pairs']+=1
            if responses['basic']=='correct' and responses['boundary']=='incorrect':comparisons['false_reject_introduced']+=1
            if responses['basic']=='incorrect' and responses['boundary']=='correct':comparisons['false_reject_corrected']+=1
    # Within-rubric matched comparisons use task id and correctness label.
    exposure=Counter()
    group=defaultdict(dict)
    for (task,correct,style),responses in pair.items():
        for rubric,prediction in responses.items():group[(task,correct,rubric)][style]=prediction
    for (task,correct,rubric),styles in group.items():
        if 'plain' not in styles:continue
        for style in ('format','confidence','placebo','instruction'):
            if style not in styles:continue
            exposure[(rubric,style,'eligible')]+=1
            if styles[style]!=styles['plain']:exposure[(rubric,style,'flips')]+=1
            if not correct and styles['plain']=='incorrect' and styles[style]=='correct':
                exposure[(rubric,style,'wrong_to_accepted')]+=1
    return by_condition,comparisons,exposure,valid


def report(cases,observations):
    counts,pairs,exposure,valid=analyze(cases,observations)
    if not observations:return '# No model observations\n\nNo results available.\n'
    providers=sorted({(r['provider'],r['model']) for r in observations})
    if len(providers)!=1: raise ValueError('Do not combine multiple model IDs or providers in one analysis')
    run_ids={r['run_id'] for r in observations}
    if len(run_ids)!=1:raise ValueError('Mixed run IDs: analyze each run independently')
    name=f'{providers[0][0]}/{providers[0][1]}'
    lines=['# Exploratory live-model observations', '', f'**Model:** `{name}`', f'**Run ID:** `{next(iter(run_ids))}`',
           f'**Recorded calls:** {len(observations)}',f'**Parseable outputs:** {valid}',
           '', '> This is a small exploratory run. Incomplete runs, missing cases and parsing errors remain visible, not converted into negative grades.',
           '', '## Condition-level outcomes', '',
           '| Rubric | Style | Valid/calls | Wrong answers accepted | Correct answers rejected | Errors | Invalid |',
           '|---|---|---:|---:|---:|---:|---:|']
    for (rubric,style),n in sorted(counts.items()):
        lines.append(f'| {rubric} | {style} | {n["valid"]}/{n["calls"]} | '
                     f'{n["false_accept"]}/{n["wrong_answer_calls"]} | '
                     f'{n["false_reject"]}/{n["correct_answer_calls"]} | '
                     f'{n["errors"]} | {n["invalid"]} |')
    lines+=['','## Paired rubric comparison','',
            f'- Same-case pairs with both outputs parseable: {pairs["both_parseable"]}',
            f'- False acceptances corrected under boundary rubric: {pairs["false_accept_corrected"]}',
            f'- False acceptances introduced under boundary rubric: {pairs["false_accept_introduced"]}',
            f'- False rejections corrected under boundary rubric: {pairs["false_reject_corrected"]}',
            f'- False rejections introduced under boundary rubric: {pairs["false_reject_introduced"]}',
            '', '## Paired style comparisons within rubrics','',
            '| Rubric | Style vs plain | Valid pairs | Verdict flips | Incorrect accepted after plain rejection |',
            '|---|---|---:|---:|---:|']
    for rubric in ('basic','boundary'):
        for style in ('format','confidence','placebo','instruction'):
            n=exposure[(rubric,style,'eligible')]
            lines.append(f'| {rubric} | {style} | {n} | {exposure[(rubric,style,"flips")]} | {exposure[(rubric,style,"wrong_to_accepted")]} |')
    lines+=['','## Interpretation and limitations','',
            '- These observations describe one selected model and this constructed task sample, not frontier-model reliability generally.',
            '- Compare instruction with the similarly long placebo condition before attributing any change to an instruction attack.',
            '- Easy tasks may show ceiling effects. No causal conclusion is justified if comparison cases or outputs are missing.',
            '- Claims about safety, statistical significance, and external validity require larger, independently reviewed work.',
            '- Verify that the chosen model ID, task labels, split, prompts, recorded outputs, and code are accurate.',
            '- Review and understand the implementation and its limitations before drawing conclusions.', '']
    return '\n'.join(lines)


def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--dataset',default='data/benchmark_v2.csv')
    p.add_argument('--results',required=True)
    p.add_argument('--out',default='results/live_analysis.md')
    a=p.parse_args(argv)
    text=report(load_csv(a.dataset),load_csv(a.results))
    out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists():p.error(f'Output already exists: {out}; use a new path')
    out.write_text(text,encoding='utf-8')
    print(text)

if __name__=='__main__':main()

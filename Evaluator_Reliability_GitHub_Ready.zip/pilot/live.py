"""Opt-in live LLM runner with per-call logging and bounded costs.

This file creates NO network calls without --allow-requests.
Uses standard-library HTTP requests, with local Ollama, Anthropic API, and OpenRouter options.
Confirm the execution environment and inspect results before interpreting findings.
"""
import argparse
import csv
import datetime
import hashlib
import json
import os
import random
import time
import uuid
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from .protocol import RUBRICS, messages, parse_verdict

COLUMNS = ('run_id','case_id','task_id','split','style','rubric','model','provider','prediction','raw_output','error','duration_ms','timestamp_utc')

def evaluate(provider, model, system, user, timeout, base_url):
    if provider=='ollama':
        endpoint=base_url.rstrip('/')+'/api/chat'
        payload={'model':model,'stream':False,'messages':[{'role':'system','content':system},
                                                            {'role':'user','content':user}],
                 'options':{'temperature':0,'num_predict':32}}
        headers={'Content-Type':'application/json'}
    elif provider=='openrouter':
        key=os.getenv('OPENROUTER_API_KEY')
        if not key: raise RuntimeError('OPENROUTER_API_KEY is not configured')
        # Fixed model ID is essential to avoid silently switching graders across calls.
        endpoint='https://openrouter.ai/api/v1/chat/completions'
        payload={'model':model,'temperature':0,'max_tokens':256,
                 'messages':[{'role':'system','content':system},
                             {'role':'user','content':user}]}
        headers={'Content-Type':'application/json','Authorization':'Bearer '+key}
    elif provider=='anthropic':
        key=os.getenv('ANTHROPIC_API_KEY')
        if not key: raise RuntimeError('ANTHROPIC_API_KEY is not configured')
        endpoint='https://api.anthropic.com/v1/messages'
        payload={'model':model,'max_tokens':32,'temperature':0,'system':system,
                 'messages':[{'role':'user','content':user}]}
        headers={'Content-Type':'application/json','anthropic-version':'2023-06-01',
                 'x-api-key':key}
    else:
        raise ValueError(provider)
    request=Request(endpoint,data=json.dumps(payload).encode(),headers=headers,method='POST')
    with urlopen(request,timeout=timeout) as response:
        result=json.load(response)
    if provider=='ollama': return result['message']['content']
    if provider=='openrouter':
        # Fail rather than quietly mixing multiple underlying models in analysis.
        # Some APIs append provider-specific revision suffixes; report them as raw metadata.
        choices=result.get('choices') or []
        if not choices: raise ValueError('OpenRouter response contained no choices')
        value=choices[0].get('message',{}).get('content')
        if not isinstance(value,str): raise ValueError('OpenRouter response contained no text content')
        return value
    return ''.join(piece.get('text','') for piece in result.get('content',[]) if piece.get('type')=='text')

def select(dataset, split, tasks, seed):
    with open(dataset,encoding='utf-8',newline='') as fh: rows=list(csv.DictReader(fh))
    subset=[r for r in rows if r['split']==split]
    all_tasks=sorted({r['task_id'] for r in subset})
    if not 1<=tasks<=len(all_tasks): raise ValueError(f'--tasks must be 1..{len(all_tasks)}')
    rng=random.Random(seed)
    rng.shuffle(all_tasks)
    chosen=set(all_tasks[:tasks])
    selected=[r for r in subset if r['task_id'] in chosen]
    per_task=len(selected)//tasks
    if len(selected)!=tasks*10 or any(sum(r['task_id']==tid for r in selected)!=10 for tid in chosen):
        raise ValueError(f'Unexpected dataset completeness; expected 10 rows per task, found {per_task}')
    return selected

def plan(dataset,split,tasks,seed,rubrics):
    cases=select(dataset,split,tasks,seed)
    pairs=[(r,rubric) for r in cases for rubric in rubrics]
    random.Random(seed+17).shuffle(pairs)
    return pairs

def main(argv=None):
    p=argparse.ArgumentParser(description='Opt-in paired LLM grader experiment')
    p.add_argument('--dataset',default='data/benchmark_v2.csv')
    p.add_argument('--provider',choices=('ollama','anthropic','openrouter'),default='ollama')
    p.add_argument('--model',default=None)
    p.add_argument('--split',choices=('development','holdout'),default='development')
    p.add_argument('--tasks',type=int,default=1)
    p.add_argument('--rubrics',choices=('both','basic','boundary'),default='both')
    p.add_argument('--seed',type=int,default=20261122)
    p.add_argument('--max-requests',type=int,default=20)
    p.add_argument('--timeout',type=int,default=90)
    p.add_argument('--delay-seconds',type=float,default=3.1,help='Pacing between free OpenRouter calls (default 3.1s)')
    p.add_argument('--base-url',default='http://127.0.0.1:11434')
    p.add_argument('--out',default='results/live_smoke.csv')
    p.add_argument('--allow-requests',action='store_true')
    args=p.parse_args(argv)
    if args.model is None:
        args.model={'ollama':'gemma3:1b','anthropic':'YOUR_AVAILABLE_MODEL_ID',
                    'openrouter':'nvidia/nemotron-3.5-lightning:free'}[args.provider]
    # Make the default no-charge experiment impossible to accidentally route to a paid model.
    if args.delay_seconds < 0:
        p.error('--delay-seconds cannot be negative')
    if args.provider=='openrouter' and not args.model.endswith(':free'):
        p.error('For this starter project OpenRouter model must end with :free; paid IDs are disabled')
    rubrics=RUBRICS if args.rubrics=='both' else (args.rubrics,)
    pairs=plan(args.dataset,args.split,args.tasks,args.seed,rubrics)
    if len(pairs)>args.max_requests: p.error(f'Request plan has {len(pairs)} calls; explicit --max-requests must cover it')
    dataset_sha=hashlib.sha256(Path(args.dataset).read_bytes()).hexdigest()
    print(f'Plan: {len(pairs)} requested model calls, {args.tasks} independent task(s), '
          f'{args.split}, rubrics={rubrics}, dataset_sha256={dataset_sha[:16]}...')
    if not args.allow_requests:
        print('DRY RUN ONLY: add --allow-requests for real model calls. No model was queried.')
        for row,rubric in pairs[:2]:
            sys,user=messages(row,rubric)
            print(f'\nExample ({row["case_id"]}, {rubric})\nSYSTEM: {sys}\nUSER: {user[:260]}')
        return 0
    if args.provider=='anthropic' and not os.environ.get('ANTHROPIC_API_KEY'):
        p.error('No ANTHROPIC_API_KEY is configured; no requests sent')
    if args.provider=='openrouter' and not os.environ.get('OPENROUTER_API_KEY'):
        p.error('No OPENROUTER_API_KEY is configured; no requests sent')
    path=Path(args.out);path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists(): p.error(f'Output already exists: {path}; choose a new path to preserve raw observations')
    run_id=str(uuid.uuid4())
    manifest={'run_id':run_id,'provider':args.provider,'model':args.model,'split':args.split,'task_count':args.tasks,
              'planned_calls':len(pairs),'seed':args.seed,'rubrics':list(rubrics),'dataset_sha256':dataset_sha,
              'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'started'}
    path.with_suffix('.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    consecutive_errors=0;errors=0;count=0
    with path.open('w',encoding='utf-8',newline='') as fh:
        writer=csv.DictWriter(fh,fieldnames=COLUMNS);writer.writeheader()
        for row,rubric in pairs:
            system,user=messages(row,rubric)
            start=time.monotonic()
            raw='';err=''
            try:
                raw=evaluate(args.provider,args.model,system,user,args.timeout,args.base_url)
                consecutive_errors=0
            except Exception as e:
                if isinstance(e,HTTPError):
                    err=f'HTTPError {e.code}'
                else:
                    err=f'{type(e).__name__}: {str(e)[:100]}'
                errors+=1;consecutive_errors+=1
            pred=parse_verdict(raw)
            writer.writerow(dict(run_id=run_id,case_id=row['case_id'],task_id=row['task_id'],split=row['split'],
                                 style=row['style'],rubric=rubric,model=args.model,provider=args.provider,
                                 prediction=pred or '',raw_output=raw,error=err,duration_ms=int(1000*(time.monotonic()-start)),
                                 timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
            fh.flush();count+=1
            if consecutive_errors>=2:
                print('Two consecutive request errors; stopping to avoid unnecessary calls and costs.')
                break
            if args.provider=='openrouter' and count<len(pairs) and args.delay_seconds:
                time.sleep(args.delay_seconds)
    final_status=('incomplete' if count!=len(pairs) else ('completed_with_errors' if errors else 'completed'))
    manifest.update(status=final_status,calls_written=count,errors=errors,
                    finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    path.with_suffix('.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(f'Recorded {count}/{len(pairs)} model responses in {path} ({errors} request errors)')
    return 0 if errors==0 else 2

if __name__=='__main__': raise SystemExit(main())
